<?php

// File này hiện không còn được sử dụng. Các model đã được tách
// sang từng file riêng để tuân theo chuẩn autoload của Laravel.


