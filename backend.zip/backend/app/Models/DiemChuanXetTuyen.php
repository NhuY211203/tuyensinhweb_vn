<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DiemChuanXetTuyen extends Model
{
    protected $table = 'diemchuanxettuyen';
    protected $primaryKey = 'iddiemchuan';
    public $timestamps = false;
    
    protected $fillable = [
        'idtruong',
        'manganh',
        'idxettuyen',
        'tohopmon',
        'diemchuan',
        'namxettuyen',
        'ghichu'
    ];
}



