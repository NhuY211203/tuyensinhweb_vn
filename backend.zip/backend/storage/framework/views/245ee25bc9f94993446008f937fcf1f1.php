<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>
    <h1>Welcome to Laravel!</h1>
</body>
</html>
<?php /**PATH D:\Năm_4_HK2\KLTN\tuyensinhweb_vn\backend\resources\views/welcome.blade.php ENDPATH**/ ?>